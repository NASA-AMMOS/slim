# Meetings

## [Meeting Name 1]
- **Purpose:** [What this meeting is for]
- **Meeting Link:** [Zoom/Teams/etc. link]
- **Frequency:** [Weekly/Biweekly/Every Tues and Thurs]
- **Day & Time:** [Day of week, Time, Timezone]
- **Duration:** [Length of meeting]
- **Attendees:** [Who typically attends]

## [Meeting Name 2]
- **Purpose:** [What this meeting is for]
- **Meeting Link:** [Zoom/Teams/etc. link]
- **Frequency:** [Weekly/Biweekly]
- **Day & Time:** [Day of week, Time, Timezone]
- **Duration:** [Length of meeting]
- **Attendees:** [Who typically attends]

... and so on for each meeting
