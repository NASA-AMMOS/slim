# Team

## Team Structure
[Brief description of the overall team structure and size]

## Leadership
- **Top-Level Manager or Principal Investigator:** [Name]
- **Project Systems Engineer:** [Name]
- **Product Delivery Managers:** 
  - [Name]
  - [Name]

## Sub-Teams

### [Sub-Team Name 1] (e.g., Frontend Team)
**Team Lead:** [Name]

#### Team Members
- **[Name 1]**
  - **Role:** [Job title/Role]
  - **Responsibilities:** [Key areas of responsibility]
  - **Contact:** [Email, Slack handle, etc.]
  - **Affiliation:** [Organizational affiliation]

- **[Name 2]**
  - **Role:** [Job title/Role]
  - **Responsibilities:** [Key areas of responsibility]
  - **Contact:** [Email, Slack handle, etc.]
  - **Affiliation:** [Organizational affiliation]

### [Sub-Team Name 2] (e.g., Backend Team)
**Team Lead:** [Name]

#### Team Members
- **[Name 1]**
  - **Role:** [Job title/Role]
  - **Responsibilities:** [Key areas of responsibility]
  - **Contact:** [Email, Slack handle, etc.]
  - **Affiliation:** [Organizational affiliation]

- **[Name 2]**
  - **Role:** [Job title/Role]
  - **Responsibilities:** [Key areas of responsibility]
  - **Contact:** [Email, Slack handle, etc.]
  - **Affiliation:** [Organizational affiliation]

## Cross-Team Contributors
- **[Name]**
  - **Role:** [Job title/Role]
  - **Responsibilities:** [Key areas of responsibility]
  - **Contact:** [Email, Slack handle, etc.]
  - **Affiliation:** [Organizational affiliation]
