# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [INSERT SEMANTIC VERSION OF RELEASE HERE] - INSERT DATE OF RELEASE HERE

### Added

- [INSERT ADDED FEATURES HERE]
- [INSERT ADDED FEATURES HERE]

### Changed

- [INSERT CHANGED FEATURES HERE]

### Removed

- [INSERT REMOVED FEATURES HERE]