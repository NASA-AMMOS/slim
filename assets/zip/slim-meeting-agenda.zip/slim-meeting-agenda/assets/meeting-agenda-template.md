# Meeting Agenda: [Meeting Name]

**Date:** [YYYY-MM-DD]
**Time:** [HH:MM - HH:MM Timezone]
**Location/Link:** [Meeting link]

## Attendees
- [Name 1] ([Role])
- [Name 2] ([Role])
- [Name 3] ([Role])

## Previous Action Items Review

| Action Item | Owner | Status | Notes |
|-------------|-------|--------|-------|
| [Description of action item from previous meeting] | [Owner Name] | [Pending/In Progress/Completed] | [Any updates or context] |
| [Description of action item from previous meeting] | [Owner Name] | [Pending/In Progress/Completed] | [Any updates or context] |

## Discussion Topics

### 1. [Topic 1]
**Background:** [Context and relevant information about this topic]
**Expected Outcome:** [What should be decided or achieved in this discussion]

### 2. [Topic 2]
**Background:** [Context and relevant information about this topic]
**Expected Outcome:** [What should be decided or achieved in this discussion]

### 3. [Topic 3]
**Background:** [Context and relevant information about this topic]
**Expected Outcome:** [What should be decided or achieved in this discussion]

## Action Items

| Action Item | Owner | Due Date | Status |
|-------------|-------|----------|--------|
| [To be assigned during meeting] | [TBD] | [TBD] | Pending |
| [To be assigned during meeting] | [TBD] | [TBD] | Pending |

---

*Agenda generated with slim-meeting-agenda skill*
*Generated on: [YYYY-MM-DD HH:MM]*
