# Meeting Summary: [Meeting Title]

## Meeting Metadata

**Date**: [YYYY-MM-DD]
**Time**: [HH:MM - HH:MM Timezone]

**Attendees**:
- [Name 1] ([Role])
- [Name 2] ([Role])
- [Name 3] ([Role])

**Meeting Type**: [Status Update / Planning / Review / Decision / etc.]

## Summary

### Key Discussion Points

1. **[Topic 1]**
   - [Key points discussed]
   - [Important details or context]

2. **[Topic 2]**
   - [Key points discussed]
   - [Important details or context]

3. **[Topic 3]**
   - [Key points discussed]
   - [Important details or context]

### Decisions Made

- **Decision 1**: [Description and rationale]
- **Decision 2**: [Description and rationale]
- **Decision 3**: [Description and rationale]

## Action Items

| Action Item | Owners | Due Date | Status |
|-------------|--------|----------|--------|
| [Description] | [Name(s)] | [YYYY-MM-DD] | Pending |
| [Description] | [Name(s)] | [YYYY-MM-DD] | Pending |
| [Description] | [Name(s)] | [YYYY-MM-DD] | Pending |

## Notes

[Any additional notes, references, links, or context]

---

*Generated with slim-meeting-summary skill*
*Workspace: [workspace-name]*
*Generated on: [YYYY-MM-DD HH:MM]*
